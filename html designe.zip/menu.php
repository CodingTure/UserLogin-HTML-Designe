			<div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-6" style="height: 50px;word-spacing: 30px;font-size: 25px;">
                    <a href="" class="btn btn-primary">Profile</a>
                    <a href="" class="btn btn-primary">Logout</a>
                    <a href="" class="btn btn-primary">Register</a>
                    <a href="" class="btn btn-primary">Login</a>
                </div>
                <div class="col-md-2"></div>
            </div>